# Jenkins

Jenkins is no longer in use, please see the [test-infra repo][test-infra] and in
particular [Prow][prow] instead.

This directory contains some scripts that are still used by the new CI.

[test-infra]: https://github.com/kubernetes/test-infra
[prow]: https://github.com/kubernetes/test-infra/tree/master/prow