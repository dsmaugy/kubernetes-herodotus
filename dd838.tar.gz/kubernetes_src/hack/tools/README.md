This directory contains a stub go module used to track version of development
tools like the ones needed for linting go sources.
