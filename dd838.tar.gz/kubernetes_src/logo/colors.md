# Official Colors

The kubernetes logo has an official blue color.  When reproducing the logo, please use the official color, when possible.

## Pantone

When possible, the Pantone color is preferred for print material.  The official Pantone color is *285C*.

## RGB

When used digitally, the official RGB color code is *#326CE5*.
