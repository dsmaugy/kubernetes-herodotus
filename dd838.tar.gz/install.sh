#!/usr/bin/bash

sudo cp herodotus_endpoint/kubectl-herodotus /usr/local/bin/